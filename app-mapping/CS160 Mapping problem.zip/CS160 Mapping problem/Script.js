


mapboxgl.accessToken = 'pk.eyJ1IjoiYi1tb250eTk4IiwiYSI6ImNtOGdoZWp1dDBuMTIya292NWVxaDQzYW4ifQ.y1yYs-pnIi_E2HxopbzOVA';
navigator.geolocation.getCurrentPosition(successLocation, errorLocation,{enableHighAccuracy: true})

function successLocation(position){
setupMap([position.coords.longitude, position.coords.latitude])
}

function errorLocation(){
    setupMap([22.56, 101.21])
}



function setupMap(center) 
{
    const map = new mapboxgl.Map({
        container: "map",
        style: "mapbox://styles/mapbox/streets-v12",
        center: center,
        zoom: 13
    })



    const nav = new mapboxgl.NavigationControl()
    map.addControl(nav)

}




