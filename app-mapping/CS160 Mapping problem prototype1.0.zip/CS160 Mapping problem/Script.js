


// token used to make the API methods work
mapboxgl.accessToken = 'pk.eyJ1IjoiYi1tb250eTk4IiwiYSI6ImNtOGdoZWp1dDBuMTIya292NWVxaDQzYW4ifQ.y1yYs-pnIi_E2HxopbzOVA';

navigator.geolocation.getCurrentPosition(successLocation, errorLocation,{enableHighAccuracy: true})

function successLocation(position){
setupMap([position.coords.longitude, position.coords.latitude])
}

function errorLocation(){
    setupMap([-122.04832192034138, 37.387197303519336])
}



// initializes the map for view in the server.
function setupMap(center) 
{
    // array storing the different values of the mao using the API defined syntax.
    const map = new mapboxgl.Map({
        container: "map",
        style: "mapbox://styles/mapbox/streets-v12",
        center: center,
        zoom: 13
    })



    const nav = new mapboxgl.NavigationControl()
    map.addControl(nav)

    //this code below is the addition of the directions capability of the API that doesnt seem to work at the moment HELP!

//     var mapboxgl = require('mapbox-gl');
//     var MapboxDirections = require('@mapbox/mapbox-gl-directions');

//     var directions = new MapboxDirections({
//   accessToken: 'pk.eyJ1IjoiYi1tb250eTk4IiwiYSI6ImNtOGdoZWp1dDBuMTIya292NWVxaDQzYW4ifQ.y1yYs-pnIi_E2HxopbzOVA'
//     });

// map.addControl(directions, 'top-left');

}




