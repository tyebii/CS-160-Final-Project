

// script for methods to setup, create, and route directions similar to google maps. WIll investigate to tweak the map to not be
// like google maps to have no changable initial spot, create blimp of starting location and a way for the user to process the POI
// to the address.
// token used to make the API methods work
mapboxgl.accessToken = 'pk.eyJ1IjoiYi1tb250eTk4IiwiYSI6ImNtOGdoZWp1dDBuMTIya292NWVxaDQzYW4ifQ.y1yYs-pnIi_E2HxopbzOVA';

// code starts making calls right here like MAIN: this is how GPS tracks your location
myCurrentLocation = navigator.geolocation.getCurrentPosition(successLocation, errorLocation,{enableHighAccuracy: true})
// end of function calls^^^^^^^


// takes the lat and long from the success location of position.coords.lat/lon
function successLocation(position){
setupMap([position.coords.longitude, position.coords.latitude])
}

// error handling but when cant find location, puts the start at the geolocation of SAN JOSE, CA
function errorLocation(){
    setupMap([-122.04832192034138, 37.387197303519336])
}



// initializes the map for view in the server and first method called upon success location being reached. (takes an array of)
function setupMap(center) 
{
    // array storing the different values of the mao using the API defined syntax.
    const map = new mapboxgl.Map({
        container: "map",
        style: "mapbox://styles/mapbox/streets-v12",
        center: center,
        zoom: 13
    })



    // nav Bar and directions for zooming in and out on the map and directions bundled into one( tried to d some things, just going to use the provided API MEthod syntax)

    /*
    HERE IS THE PROPER SYNTAX FOR CREATING MAP CONTROLS LIKE NAV BARS AND DIRECTIONS BOXES:
    
    const {var name} = new mapboxgl.NavigationCOntrol(); --> creates nav zoom bar object

    steps for adding them to map:
    1. map.addCOntrol({var name}, {location}); --> locations: 'top-left, top-right, bottom-right, bottom-left
    2. map.addControl({some map object}({
            {array parameters}}, {location});
    }))
        LSDR version, start with map.addCOntrol then throw your other map objects into it to create the specific parts.

        addControl( takes the map object with its array parameters, then the string of location on map)
    */

    const nav = new mapboxgl.NavigationControl();
    map.addControl(nav, 'top-right');

    // imaginary store location is MLK library
    const fixedOrigin = [-121.885239, 37.335640];
    // add our directions with proper set up to the map.
    
    // directions object for our mapping UI with specific rules.
    directionsUI = new MapboxDirections({
        accessToken: mapboxgl.accessToken,
        profile: 'mapbox/driving',
        interactive: false,
        origin: fixedOrigin,
        controls: {
            inputs: true,
            instructions: true
        },
        destinationInputControl: true,
        originInputControl: false,


    });

    // adding directions feature to the map UI.
    map.addControl(directionsUI, 'top-left');
  
    // hard setting the origin of the MLK Library in directions.
    directionsUI.setOrigin(fixedOrigin);

}




