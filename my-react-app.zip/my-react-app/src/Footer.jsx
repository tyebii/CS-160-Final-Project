 function Footer(){
    return(
        <footer>
            <p> 
                &copy; { new Date().getFullYear()} OFS.COM
            </p>
        </footer>
    )

 }
 export default Footer