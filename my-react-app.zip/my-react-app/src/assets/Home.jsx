const Home = () => {

    const handleClick = () => {
        console.log("User has chosen X");
    }
    return ( 
        <div className="Home">
            <h2>Login or Sign Up</h2>
            <br></br>
            <button onClick={handleClick}> Continue With X</button>
            <button onCLick={handleClick}> Continue With Gmail</button>
            <button onCLick={handleClick}> Continue with Meta </button>
        </div>
     );
}
 
export default Home;