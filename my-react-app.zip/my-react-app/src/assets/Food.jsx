function Food(){

const food1 = "Orange";
const food2 = "apple";
return(
    <>
    <ul>
        <li>Apple</li>
        <li>{food1}</li>
        <li>{food2}</li>

    </ul>
    </>
);
}

export default Food