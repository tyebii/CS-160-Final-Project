
    const Navbar  = () => {
        return ( 
            <nav className="navbar">
                <img src="my-react-app\src\assets\OFS_Logo.png" className="Logo"></img>
                <h1> OFS Login</h1>
                <div className="links">
                    <search>
                        <form>
                            <input name="fsrch" id="fsrch" placeholder="Search"></input>
                        </form>
                    </search>
                    <a href="#">Login</a>
                    <a href="#">Shopping Cart</a>
                </div>

            </nav>
        );
    }
export default Navbar;
    