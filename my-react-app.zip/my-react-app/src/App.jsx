import Footer from "./assets/Footer.jsx";
import Navbar from "./assets/Navbar.jsx";
import Food from "./assets/Food.jsx";
import Home from "./assets/Home.jsx";
function App() {
  return(
    <>
    <div className="App">
      <Navbar/>
      <div className="Content">
        <Home/>
      </div>
    </div>
      
      {/* <Food/>
      <Food/> */}
      <Footer/>
    </>

  );
}

export default App
