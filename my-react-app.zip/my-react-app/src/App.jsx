import Footer from "./Footer.jsx";
import Header from "./assets/Header.jsx"
import Food from "./assets/Food.jsx";
function App() {
  return(
    <>
      <Header/>
      <Food/>
      <Food/>
      <Footer/>
    </>

  );
}

export default App
